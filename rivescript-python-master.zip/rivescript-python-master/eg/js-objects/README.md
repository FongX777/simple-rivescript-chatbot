# JavaScript Object Macros

This example demonstrates how a RiveScript-Python bot may support JavaScript as
a language for object macros.

This assumes that the Python bot is serving its responses via a web front-end,
and that the end user's browser will be executing the JavaScript macros via
`<script>` tags.
