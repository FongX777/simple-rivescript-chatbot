.. rivescript documentation master file, created by
   sphinx-quickstart on Thu May 12 16:16:02 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to rivescript's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 4

   rivescript


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

